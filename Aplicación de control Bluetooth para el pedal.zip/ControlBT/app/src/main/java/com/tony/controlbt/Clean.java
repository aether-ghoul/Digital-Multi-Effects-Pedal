package com.tony.controlbt;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

public class Clean extends AppCompatActivity {


    private static SeekBar volumen;
    private static TextView porcentaje;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clean);
        cambiarvolumen();




    }

    private void cambiarvolumen() {
      volumen = (SeekBar)findViewById(R.id.idvol1);
     porcentaje= (TextView) findViewById(R.id.idporsento);
     porcentaje.setText("POT2 VOLUMEN = "+volumen.getProgress());

     volumen.setOnSeekBarChangeListener(

             new SeekBar.OnSeekBarChangeListener() {

                 int volumen_progreso;
                 String cadena = Integer.toString(volumen_progreso);

                 @Override

                 public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                     volumen_progreso = progress;
                     porcentaje.setText("POT2 VOLUMEN = "+progress );
                                     }

                 @Override
                 public void onStartTrackingTouch(SeekBar seekBar) {

                 }

                 @Override
                 public void onStopTrackingTouch(SeekBar seekBar) {
                     porcentaje.setText("POT2 VOLUMEN = "+volumen_progreso );

                     Toast.makeText(Clean.this, "¡Volumen modificado!", Toast.LENGTH_LONG).show();
                 }
             }


     );
    }









}

package com.tony.controlbt;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class Chorus extends AppCompatActivity {
    private static SeekBar volumen, velocidad;
    private static TextView porcentaje1, porcentaje2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chorus);
        cambiarvolumen();
        cambiarvelocidad();
    }

    private void cambiarvolumen() {
        volumen = (SeekBar)findViewById(R.id.idvolumenchorus);
        porcentaje1= (TextView) findViewById(R.id.idporcentajevolchorus);
        porcentaje1.setText("POT2 VOLUMEN = "+volumen.getProgress());

        volumen.setOnSeekBarChangeListener(

                new SeekBar.OnSeekBarChangeListener() {
                    int volumen_progreso;
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        volumen_progreso = progress;
                        porcentaje1.setText("POT2 VOLUMEN = "+progress );

                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        porcentaje1.setText("POT2 VOLUMEN = "+volumen_progreso );
                        Toast.makeText(Chorus.this, "¡Volumen modificado!", Toast.LENGTH_LONG).show();
                    }
                }

        );
    }

    private void cambiarvelocidad() {
        velocidad = (SeekBar)findViewById(R.id.idvelocidadchorus);
        porcentaje2= (TextView) findViewById(R.id.idporcentajevelocidadchorus);
        porcentaje2.setText("POT0 VELOCIDAD = "+velocidad.getProgress());

        velocidad.setOnSeekBarChangeListener(

                new SeekBar.OnSeekBarChangeListener() {
                    int volumen_progreso;
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        volumen_progreso = progress;
                        porcentaje2.setText("POT0 VELOCIDAD = "+progress );

                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        porcentaje2.setText("POT0 VELOCIDAD = "+volumen_progreso );
                        Toast.makeText(Chorus.this, "¡Velocidad de LFO modificada!", Toast.LENGTH_LONG).show();
                    }
                }

        );
    }
}

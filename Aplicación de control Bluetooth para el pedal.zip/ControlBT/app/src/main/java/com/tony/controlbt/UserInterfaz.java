package com.tony.controlbt;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.UUID;

public class UserInterfaz extends AppCompatActivity {

    Button IdEncender, IdApagar,IdDesconectar, IdOctaver, IdDelay, IdTremolo, IdNuevo;
    TextView IdBufferIn;
    //-------------------------------------------
    private static Handler bluetoothIn;
    private final int handlerState = 0;
    private BluetoothAdapter btAdapter = null;
    private BluetoothSocket btSocket = null;
    private StringBuilder DataStringIN = new StringBuilder();
    private ConnectedThread MyConexionBT;

    // Identificador unico de servicio - SPP UUID
    public static final UUID BTMODULEUUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    // String para la direccion MAC
    public static String address = null;
    //-------------------------------------------

    private static SeekBar volumen;
    private static TextView porcentaje;

    private static SeekBar barrapot1;
    private static TextView textopot1;

    private static SeekBar barrapot0;
    private static TextView textopot0;


    private static TextView potenciometro2;
    private static TextView potenciometro1;
    private static TextView potenciometro0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_interfaz);
        //2)
        //Enlaza los controles con sus respectivas vistas
        IdEncender = (Button) findViewById(R.id.idencender);
        IdApagar = (Button) findViewById(R.id.idapagar);
        IdDesconectar = (Button) findViewById(R.id.iddesconectar);
        IdBufferIn = (TextView) findViewById(R.id.idbufferin);

        IdOctaver = (Button) findViewById(R.id.idoctavador);
        IdDelay = (Button) findViewById(R.id.iddelay);
        IdTremolo = (Button) findViewById(R.id.idtremolo);
        IdNuevo = (Button) findViewById(R.id.idnuevo);

        potenciometro2 = (TextView)findViewById(R.id.pote2) ;
        potenciometro1 = (TextView)findViewById(R.id.pote1) ;
        potenciometro0 = (TextView)findViewById(R.id.pote0) ;

        bluetoothIn = new Handler() {
            public void handleMessage(android.os.Message msg) {
                if (msg.what == handlerState) {
                    String readMessage = (String) msg.obj;
                    DataStringIN.append(readMessage);

                    int endOfLineIndex = DataStringIN.indexOf("#");

                    if (endOfLineIndex > 0) {
                        String dataInPrint = DataStringIN.substring(0, endOfLineIndex);
                        IdBufferIn.setText("Efecto " + dataInPrint);//<-<- PARTE A MODIFICAR >->->
                        DataStringIN.delete(0, DataStringIN.length());
                    }
                }
            }
        };

        btAdapter = BluetoothAdapter.getDefaultAdapter(); // get Bluetooth adapter
        VerificarEstadoBT();

        // Configuracion onClick listeners para los botones
        // para indicar que se realizara cuando se detecte
        // el evento de Click
        IdEncender.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                MyConexionBT.write("a");
                Toast.makeText(UserInterfaz.this, "¡Efecto Clean seleccionado", Toast.LENGTH_LONG).show();
                potenciometro2.setText("Volumen");
                potenciometro1.setText("No disponible");
                potenciometro0.setText("No disponible");
                IdEncender.setBackgroundColor(Color.parseColor("#303f9f"));
                IdDelay.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdTremolo.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdOctaver.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdApagar.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdNuevo.setBackgroundColor(Color.parseColor("#d6d7d7"));

            }
        });

        IdApagar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                MyConexionBT.write("b");
                Toast.makeText(UserInterfaz.this, "¡Efecto Distortion seleccionado!", Toast.LENGTH_LONG).show();
                potenciometro2.setText("Volumen");
                potenciometro1.setText("Limite Superior");
                potenciometro0.setText("Limite Inferior");
                IdApagar.setBackgroundColor(Color.parseColor("#303f9f"));
                IdDelay.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdTremolo.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdOctaver.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdNuevo.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdEncender.setBackgroundColor(Color.parseColor("#d6d7d7"));
            }
        });

        IdOctaver.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                MyConexionBT.write("c");
                Toast.makeText(UserInterfaz.this, "¡Efecto Echo seleccionado!", Toast.LENGTH_LONG).show();
                potenciometro2.setText("Volumen");
                potenciometro1.setText("No disponible");
                potenciometro0.setText("Velocidad repeticiones");
                IdOctaver.setBackgroundColor(Color.parseColor("#303f9f"));
                IdDelay.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdTremolo.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdNuevo.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdApagar.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdEncender.setBackgroundColor(Color.parseColor("#d6d7d7"));
            }
        });

        IdTremolo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                MyConexionBT.write("d");
                Toast.makeText(UserInterfaz.this, "¡Efecto Chorus seleccionado!", Toast.LENGTH_LONG).show();
                potenciometro2.setText("Volumen");
                potenciometro1.setText("No disponible");
                potenciometro0.setText("Velocidad oscilador");
                IdTremolo.setBackgroundColor(Color.parseColor("#303f9f"));
                IdDelay.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdNuevo.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdOctaver.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdApagar.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdEncender.setBackgroundColor(Color.parseColor("#d6d7d7"));
            }
        });

        IdDelay.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                MyConexionBT.write("e");
                Toast.makeText(UserInterfaz.this, "¡Efecto Tremolo seleccionado!", Toast.LENGTH_LONG).show();
                potenciometro2.setText("Volumen");
                potenciometro1.setText("Profundidad");
                potenciometro0.setText("Velocidad oscilador");
                IdDelay.setBackgroundColor(Color.parseColor("#303f9f"));
                IdNuevo.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdTremolo.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdOctaver.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdApagar.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdEncender.setBackgroundColor(Color.parseColor("#d6d7d7"));
            }
        });

        IdNuevo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                MyConexionBT.write("f");
                Toast.makeText(UserInterfaz.this, "¡Efecto Octaver seleccionado!", Toast.LENGTH_LONG).show();
                potenciometro2.setText("Volumen");
                potenciometro1.setText("No disponible");
                potenciometro0.setText("Octava");
                IdNuevo.setBackgroundColor(Color.parseColor("#303f9f"));
                IdDelay.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdTremolo.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdOctaver.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdApagar.setBackgroundColor(Color.parseColor("#d6d7d7"));
                IdEncender.setBackgroundColor(Color.parseColor("#d6d7d7"));
            }
        });

        IdDesconectar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                MyConexionBT.write("p");
            }
        });


        cambiarvolumen();
        cambiarpot1();
        cambiarpot0();


    }



    private BluetoothSocket createBluetoothSocket(BluetoothDevice device) throws IOException
    {
        //crea un conexion de salida segura para el dispositivo
        //usando el servicio UUID
        return device.createRfcommSocketToServiceRecord(BTMODULEUUID);
    }

    @Override
    public void onResume()
    {
        super.onResume();
        //Consigue la direccion MAC desde DeviceListActivity via intent
        Intent intent = getIntent();
        //Consigue la direccion MAC desde DeviceListActivity via EXTRA
        address = intent.getStringExtra(DispositivosBT.EXTRA_DEVICE_ADDRESS);//<-<- PARTE A MODIFICAR >->->
        //Setea la direccion MAC
        BluetoothDevice device = btAdapter.getRemoteDevice(address);

        try
        {
            btSocket = createBluetoothSocket(device);
        } catch (IOException e) {
            Toast.makeText(getBaseContext(), "La creación del Socket fallo", Toast.LENGTH_LONG).show();
        }
        // Establece la conexión con el socket Bluetooth.
        try
        {
            btSocket.connect();
        } catch (IOException e) {
            try {
                btSocket.close();
            } catch (IOException e2) {}
        }
        MyConexionBT = new ConnectedThread(btSocket);
        MyConexionBT.start();
    }

    @Override
    public void onPause()
    {
        super.onPause();
        try
        { // Cuando se sale de la aplicación esta parte permite
            // que no se deje abierto el socket
            btSocket.close();
        } catch (IOException e2) {}
    }

    //Comprueba que el dispositivo Bluetooth Bluetooth está disponible y solicita que se active si está desactivado
    private void VerificarEstadoBT() {

        if(btAdapter==null) {
            Toast.makeText(getBaseContext(), "El dispositivo no soporta bluetooth", Toast.LENGTH_LONG).show();
        } else {
            if (btAdapter.isEnabled()) {
            } else {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, 1);
            }
        }
    }

    //Crea la clase que permite crear el evento de conexion
    public class ConnectedThread extends Thread
    {
        public final InputStream mmInStream;
        public final OutputStream mmOutStream;

        public ConnectedThread(BluetoothSocket socket)
        {
            InputStream tmpIn = null;
            OutputStream tmpOut = null;
            try
            {
                tmpIn = socket.getInputStream();
                tmpOut = socket.getOutputStream();
            } catch (IOException e) { }
            mmInStream = tmpIn;
            mmOutStream = tmpOut;
        }

        public void run()
        {
            byte[] buffer = new byte[256];
            int bytes;

            // Se mantiene en modo escucha para determinar el ingreso de datos
            while (true) {
                try {
                    bytes = mmInStream.read(buffer);
                    String readMessage = new String(buffer, 0, bytes);
                    // Envia los datos obtenidos hacia el evento via handler
                    bluetoothIn.obtainMessage(handlerState, bytes, -1, readMessage).sendToTarget();
                } catch (IOException e) {
                    break;
                }
            }
        }
        //Envio de trama
        public void write(String input)
        {
            try {
                mmOutStream.write(input.getBytes());
            }
            catch (IOException e)
            {
                //si no es posible enviar datos se cierra la conexión
                Toast.makeText(getBaseContext(), "La Conexión fallo", Toast.LENGTH_LONG).show();
              finish();
            }
        }
    }

    private void cambiarvolumen() {
        volumen = (SeekBar)findViewById(R.id.idpot2barra);
        porcentaje= (TextView) findViewById(R.id.idpot2);
        porcentaje.setText("POT2 = "+volumen.getProgress());

        volumen.setOnSeekBarChangeListener(

                new SeekBar.OnSeekBarChangeListener() {

                    int volumen_progreso;


                    @Override

                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        volumen_progreso = progress;

                        porcentaje.setText("POT2 = "+progress );
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                        MyConexionBT.write("x");
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        porcentaje.setText("POT2 = "+volumen_progreso );

                        String cadena = Integer.toString(volumen_progreso);
                        MyConexionBT.write(cadena);
                        Toast.makeText(UserInterfaz.this, "¡POT2 modificado!", Toast.LENGTH_LONG).show();
                    }
                }


        );
    }



    private void cambiarpot1() {
        barrapot1= (SeekBar)findViewById(R.id.idpot1barra);
        textopot1= (TextView) findViewById(R.id.idpot1);
        textopot1.setText("POT1 = "+barrapot1.getProgress());

        barrapot1.setOnSeekBarChangeListener(

                new SeekBar.OnSeekBarChangeListener() {

                    int volumen_progreso;


                    @Override

                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        volumen_progreso = progress;

                        textopot1.setText("POT1 = "+progress );
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                        MyConexionBT.write("y");
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        textopot1.setText("POT1 = "+volumen_progreso );

                        String cadena = Integer.toString(volumen_progreso);
                        MyConexionBT.write(cadena);
                        Toast.makeText(UserInterfaz.this, "¡POT1 modificado!", Toast.LENGTH_LONG).show();
                    }
                }


        );
    }

    private void cambiarpot0() {
        barrapot0= (SeekBar)findViewById(R.id.idpot0barra);
        textopot0= (TextView) findViewById(R.id.idpot0);
        textopot0.setText("POT0 = "+barrapot0.getProgress());

        barrapot0.setOnSeekBarChangeListener(

                new SeekBar.OnSeekBarChangeListener() {

                    int volumen_progreso;


                    @Override

                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        volumen_progreso = progress;

                        textopot0.setText("POT0 = "+progress );
                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                        MyConexionBT.write("z");
                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        textopot0.setText("POT0 = "+volumen_progreso );

                        String cadena = Integer.toString(volumen_progreso);
                        MyConexionBT.write(cadena);
                        Toast.makeText(UserInterfaz.this, "¡POT0 modificado!", Toast.LENGTH_LONG).show();
                    }
                }


        );
    }



}


package com.tony.controlbt;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class Tremolo extends AppCompatActivity {
    private static SeekBar volumen, profundidad, velocidad;
    private static TextView porcentaje1, porcentaje2, porcentaje3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tremolo);
        cambiarvolumen();
        cambiarprofundidad();
        cambiarvelocidad();
    }

    private void cambiarvolumen() {
        volumen = (SeekBar)findViewById(R.id.idvolumentremolo);
        porcentaje1= (TextView) findViewById(R.id.idporcentajevoltremolo);
        porcentaje1.setText("POT2 VOLUMEN = "+volumen.getProgress());

        volumen.setOnSeekBarChangeListener(

                new SeekBar.OnSeekBarChangeListener() {
                    int volumen_progreso;
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        volumen_progreso = progress;
                        porcentaje1.setText("POT2 VOLUMEN = "+progress );

                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        porcentaje1.setText("POT2 VOLUMEN = "+volumen_progreso );
                        Toast.makeText(Tremolo.this, "¡Volumen modificado!", Toast.LENGTH_LONG).show();
                    }
                }

        );
    }

    private void cambiarprofundidad() {
        profundidad = (SeekBar)findViewById(R.id.idprofundidadtremolo);
        porcentaje2= (TextView) findViewById(R.id.idporcentajeprofundidadtremolo);
        porcentaje2.setText("POT1 PROFUNDIDAD = "+profundidad.getProgress());

        profundidad.setOnSeekBarChangeListener(

                new SeekBar.OnSeekBarChangeListener() {
                    int volumen_progreso;
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        volumen_progreso = progress;
                        porcentaje2.setText("POT1 PROFUNDIDAD = "+progress );

                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        porcentaje2.setText("POT1 PROFUNDIDAD = "+volumen_progreso );
                        Toast.makeText(Tremolo.this, "¡Profunididad de señal modificada!", Toast.LENGTH_LONG).show();
                    }
                }

        );
    }

    private void cambiarvelocidad() {
        velocidad = (SeekBar)findViewById(R.id.idvelocidadtremolo);
        porcentaje3= (TextView) findViewById(R.id.idporcentajevelocidadtremolo);
        porcentaje3.setText("POT0 VELOCIDAD = "+velocidad.getProgress());

        velocidad.setOnSeekBarChangeListener(

                new SeekBar.OnSeekBarChangeListener() {
                    int volumen_progreso;
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        volumen_progreso = progress;
                        porcentaje3.setText("POT0 VELOCIDAD = "+progress );

                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        porcentaje3.setText("POT0 VELOCIDAD = "+volumen_progreso );
                        Toast.makeText(Tremolo.this, "¡Velocidad de LFO modificada!", Toast.LENGTH_LONG).show();
                    }
                }

        );
    }
}

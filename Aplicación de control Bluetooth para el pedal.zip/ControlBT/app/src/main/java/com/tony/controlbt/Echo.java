package com.tony.controlbt;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class Echo extends AppCompatActivity {


    private static SeekBar volumen, repeticiones;
    private static TextView porcentaje1, porcentaje2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_echo);
        cambiarvolumen();
        cambiarrepeticiones();
    }

    private void cambiarvolumen() {
        volumen = (SeekBar)findViewById(R.id.idvol2);
        porcentaje1= (TextView) findViewById(R.id.idporsento10);
        porcentaje1.setText("POT2 VOLUMEN = "+volumen.getProgress());

        volumen.setOnSeekBarChangeListener(

                new SeekBar.OnSeekBarChangeListener() {
                    int volumen_progreso;
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        volumen_progreso = progress;
                        porcentaje1.setText("POT2 VOLUMEN = "+progress );

                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        porcentaje1.setText("POT2 VOLUMEN = "+volumen_progreso );
                        Toast.makeText(Echo.this, "¡Volumen modificado!", Toast.LENGTH_LONG).show();
                    }
                }

        );
    }


    private void cambiarrepeticiones() {
        repeticiones = (SeekBar)findViewById(R.id.idrepe);
        porcentaje2= (TextView) findViewById(R.id.idporsento9);
        porcentaje2.setText("POT0 REPETICIONES = "+repeticiones.getProgress());

        repeticiones.setOnSeekBarChangeListener(

                new SeekBar.OnSeekBarChangeListener() {
                    int volumen_progreso;
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        volumen_progreso = progress;
                        porcentaje2.setText("POT0 REPETICIONES = "+progress );

                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        porcentaje2.setText("POT0 REPETICIONES = "+volumen_progreso );
                        Toast.makeText(Echo.this, "¡Repeticiones modificadas!", Toast.LENGTH_LONG).show();
                    }
                }

        );
    }
}

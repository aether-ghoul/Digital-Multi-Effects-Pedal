package com.tony.controlbt;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class Octaver extends AppCompatActivity {
    private static SeekBar volumen;
    private static TextView porcentaje, idoctava;
    private Button abajo, arriba, actual;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_octaver);
        cambiarvolumen();


        abajo = (Button) findViewById(R.id.idoctavaabajo);
        arriba = (Button) findViewById(R.id.idoctavaarriba);
        actual = (Button) findViewById(R.id.idoctavaactual);
        idoctava = (TextView) findViewById(R.id.idoctavaa);


        abajo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
               idoctava.setText("OCTAVA ABAJO");
            }
        });

        actual.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                idoctava.setText("OCTAVA ACTUAL");
            }
        });

        arriba.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                idoctava.setText("OCTAVA ARRIBA");
            }
        });
    }

    private void cambiarvolumen() {
        volumen = (SeekBar)findViewById(R.id.idvolumenoctavador);
        porcentaje= (TextView) findViewById(R.id.idporcentajevolumenoctavador);
        porcentaje.setText("POT2 VOLUMEN = "+volumen.getProgress());

        volumen.setOnSeekBarChangeListener(

                new SeekBar.OnSeekBarChangeListener() {
                    int volumen_progreso;
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        volumen_progreso = progress;
                        porcentaje.setText("POT2 VOLUMEN = "+progress );

                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        porcentaje.setText("POT2 VOLUMEN = "+volumen_progreso );
                        Toast.makeText(Octaver.this, "¡Volumen modificado!", Toast.LENGTH_LONG).show();
                    }
                }

        );
    }
}

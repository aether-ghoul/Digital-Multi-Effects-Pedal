package com.tony.controlbt;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class Distortion extends AppCompatActivity {


    private static SeekBar volumen, limite1, limite2;
    private static TextView porcentaje1, porcentaje2, porcentaje3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_distortion);
        cambiarvolumen();
        cambiarlimite1();
        cambiarlimite2();
    }

    private void cambiarvolumen() {
        volumen = (SeekBar)findViewById(R.id.idvol1);
        porcentaje1= (TextView) findViewById(R.id.idporsento2);
        porcentaje1.setText("POT2 VOLUMEN = "+volumen.getProgress());

        volumen.setOnSeekBarChangeListener(

                new SeekBar.OnSeekBarChangeListener() {
                    int volumen_progreso;
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        volumen_progreso = progress;
                        porcentaje1.setText("POT2 VOLUMEN = "+progress );

                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        porcentaje1.setText("POT2 VOLUMEN = "+volumen_progreso );
                        Toast.makeText(Distortion.this, "¡Volumen modificado!", Toast.LENGTH_LONG).show();
                    }
                }

        );
    }


    private void cambiarlimite1() {
        limite1 = (SeekBar)findViewById(R.id.idsegundabarra);
        porcentaje2= (TextView) findViewById(R.id.idporsento3);
        porcentaje2.setText("POT1  LIMITE INFERIOR= "+limite1.getProgress());

        limite1.setOnSeekBarChangeListener(

                new SeekBar.OnSeekBarChangeListener() {
                    int limite1_progreso;
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        limite1_progreso = progress;
                        porcentaje2.setText("POT1  LIMITE INFERIOR= "+progress );

                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        porcentaje2.setText("POT1  LIMITE INFERIOR= "+limite1_progreso);
                        Toast.makeText(Distortion.this, "¡Límite inferior modificado!", Toast.LENGTH_LONG).show();
                    }
                }

        );
    }


    private void cambiarlimite2() {
        limite2 = (SeekBar)findViewById(R.id.idlimsup);
        porcentaje3= (TextView) findViewById(R.id.idporsento4);
        porcentaje3.setText("POT0 LIMITE SUPERIOR= "+limite2.getProgress());

        limite2.setOnSeekBarChangeListener(

                new SeekBar.OnSeekBarChangeListener() {
                    int limite2_progreso;
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        limite2_progreso = progress;
                        porcentaje3.setText("POT0 LIMITE SUPERIOR= "+progress );

                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        porcentaje3.setText("POT0 LIMITE SUPERIOR= "+limite2_progreso);
                        Toast.makeText(Distortion.this, "¡Límite superior modificado!", Toast.LENGTH_LONG).show();
                    }
                }

        );
    }
}
